package concurency;

public class Program implements Runnable {
    private String name;

    public Program(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public void run() {
        System.out.printf("Program %s is running\n", getName());
    }
}
