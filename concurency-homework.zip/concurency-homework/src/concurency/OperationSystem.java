package concurency;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

public class OperationSystem {

    private static int programCounter = 0;

    static synchronized void increaseProgramCounter() {
        programCounter += 1;
    }

    static synchronized void decreaseProgramCounter() {
        programCounter -= 1;
    }

    public static void main(String[] args) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ss");
        List<String> programNames = new ArrayList(Arrays.asList("pro1", "pro2", "pro3", "pro4", "pro5", "pro6",
                "pro7", "pro8", "pro9", "pro10"));
        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(10);
        ScheduledExecutorService executorCounter = Executors.newScheduledThreadPool(1);
        Map<String, Program> programs = new HashMap<>();
        Map<String, ScheduledFuture<?>> futures = new HashMap<>();

        for (int i = 0; i < 10; i++) {
            programs.put(programNames.get(i), new Program(programNames.get(i)));
        }

        System.out.println("Operating System is started");

        Runnable countTask = () -> System.out.println("Current number of running programs is: " + programCounter);

        executorCounter.scheduleAtFixedRate(countTask, 25, 25, TimeUnit.SECONDS);

        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNext()) {
            String command = scanner.nextLine();
            ScheduledFuture<?> futureToStart;
            String programName;

            if (command.contains("start ")) {

                programName = command.replace("start ", "");

                Integer delay = Integer.valueOf(dtf.format(LocalDateTime.now())) % 15;

                try {
                    futureToStart = executorService.scheduleAtFixedRate(programs.get(programName), (15 - delay), 15, TimeUnit.SECONDS);
                    futures.put(programName, futureToStart);

                    increaseProgramCounter();

                    System.out.printf("Program %s is started\n", programName);
                } catch (NullPointerException npe) {
                    System.out.println("Typed program is not installed on your Operating System!");
                }

            }

            if (command.contains("stop ")) {

                programName = command.replace("stop ", "");

                Future futureToStop = futures.get(programName);

                if (futureToStop != null) {

                    if (futureToStop.cancel(true)) {
                        decreaseProgramCounter();
                    }

                    System.out.printf("Program %s is stopped\n", programName);
                } else {
                    System.out.println("Typed program is not installed on your Operating System!");
                }
            }


            if (command.contains("shutdown")) {

                System.out.println("Shutting down ...");

                executorService.shutdown();
                executorCounter.shutdown();

                break;
            }
        }

    }
}
